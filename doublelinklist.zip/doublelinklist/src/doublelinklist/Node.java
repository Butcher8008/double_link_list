package doublelinklist;

public class Node {
	
	int value;
	Node previous;
	Node next;
	
	

}
