package doublelinklist;

public class doublelinklist {
		Node head;
		int size;
		
		public void addinfront(int v)
		{
			Node nNode=new Node();
			
			nNode.previous=null;
			nNode.value=v;
			nNode.next=null;
			
			if(head==null)
			{
				head=nNode;
			}
			else
			{
				Node tNode=head;
				while(tNode.next!=null)
				{
					tNode=tNode.next;
				}
				tNode.next=nNode;
			}
		}
		public void addatlast(int v) {
			
			Node nNode=new Node();
			
			nNode.previous=null;
			nNode.value=v;
			nNode.next=null;
			
			if(head==null) {
				head=nNode;
			}
			else{
				head.previous=nNode;
				head=nNode;
			}
			
		}
		public void addat(int value,int index) {
			if(head==null) {
				return;
			}
			if(index<1 || index>size) {
				return;
			}
			Node tNode=head;
			int i=1;
			while(i<index) {
				tNode=tNode.next;
				i++;
			}
			if(tNode.previous==null) {
				Node nNode=new Node();
				nNode.previous=null;
				nNode.value=value;
				nNode.next=tNode;
				
				tNode.previous=nNode;
				head=nNode;
			}
			else {
				Node nNode=new Node();
				nNode.previous=tNode.previous;
				nNode.value=value;
				nNode.next=tNode;
				
				tNode.previous.next=nNode;
				tNode.previous=nNode;
				
			}
			size++;
		}
		public void removefromright(int v)
		{
			Node tNode=head;
			Node pNode=head;
			
			if(head.value==v)
			{
				head=head.next;
			}
			else {
			while(tNode.next!=null)
			{
				if(tNode.value==v){
					pNode.next=tNode.next;
					break;
				}
				pNode=tNode;
				tNode=tNode.next;
				}
			}
		}
		public void removefromleft(int v)
		{
			Node tNode=head;
			Node pNode=head;
			
			if(head.value==v)
			{
				head=head.next;
				head.previous=null;
			}
		}
		public void removeall() {
			head.next=null;
			head.previous=null;
			
		}
		
		public boolean isEmpty() {
			return head==null;
		}
		public boolean find(int v) {
			
			Node tNode=head;	
			
			while(tNode!=null) {
				
				if (tNode.value==v) {
					
					return true;
					
				}
				
				tNode=tNode.next;

			}		
			return false;
		}
		
		public void display()
		{
			Node tNode=head;
			while(tNode!=null)
			{
				System.out.print(tNode.value + "\t");
				tNode=tNode.next;
			}
			System.out.println();
		}
		
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		doublelinklist l=new doublelinklist();
		
		l.addatlast(1);
		l.addinfront(2);
		l.addinfront(4);
		l.addinfront(6);
		l.addinfront(10);
//		l.removefromright(2);
//		l.removefromleft(1);
//		l.removeall();
//		l.addat(3, 7);
		l.display();
	}

}
